import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deleteTask, editTask } from '../store/actions';
import { ListGroup, Button, Row, Col } from 'react-bootstrap';

const TaskList = () => {
  const tasks = useSelector(state => state.tasks);
  const dispatch = useDispatch();

  return (
    <ListGroup>
      {tasks.map((task, index) => (
        <ListGroup.Item key={index}>
          <Row>
            <Col xs={8}>{task}</Col>
            <Col xs={4} className="text-end">
              <Button variant="warning" onClick={() => dispatch(editTask(index, prompt('Edit task:', task)))}>Edit</Button>{' '}
              <Button variant="danger" onClick={() => dispatch(deleteTask(index))}>Delete</Button>
            </Col>
          </Row>
        </ListGroup.Item>
      ))}
    </ListGroup>
  );
};

export default TaskList;
