import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addTask } from '../store/actions';
import { Form, Button, InputGroup } from 'react-bootstrap';

const TaskInput = () => {
  const [task, setTask] = useState('');
  const dispatch = useDispatch();

  const handleAddTask = () => {
    if (task.trim()) {
      dispatch(addTask(task));
      setTask('');
    }
  };

  return (
    <Form>
      <InputGroup className="mb-3">
        <Form.Control 
          type="text"
          value={task}
          onChange={(e) => setTask(e.target.value)}
          placeholder="Add a new task"
        />
        <Button variant="primary" onClick={handleAddTask}>Add Task</Button>
      </InputGroup>
    </Form>
  );
};

export default TaskInput;
