import React from 'react';
import TaskInput from './Components/TaskInput';
import TaskList from './Components/TaskList';
import StoreProvider from './store/store';
import { Container, Row, Col } from 'react-bootstrap';
import './App.css';

const App = () => {
  return (
    <StoreProvider>
      <Container>
        <Row className="justify-content-md-center">
          <Col xs={12} md={8}>
            <h1 className="text-center my-4">React To-Do App</h1>
            <TaskInput />
            <TaskList />
          </Col>
        </Row>
      </Container>
    </StoreProvider>
  );
};

export default App;
